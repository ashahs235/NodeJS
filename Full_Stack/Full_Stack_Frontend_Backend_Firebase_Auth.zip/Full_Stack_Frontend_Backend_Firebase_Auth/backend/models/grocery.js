const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const GrocerySchema = new Schema({
    groceryItem : String,
    isPurchased : Boolean, 
    //isPurchased works for multiple items : should be binded to individual item, first add grocery items & then mark the item as purchased in frontend UI
},
{
    collection : "GroceryItems",
}
);

module.exports = mongoose.model("GroceryItems", GrocerySchema);