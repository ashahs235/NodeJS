import firebase from 'firebase/compat/app';
import  "firebase/compat/firestore";
import 'firebase/compat/auth'; //email/password management in frontend

//Connection to remote firebase server
const firebaseConfig = {
    apiKey: "AIzaSyBynPk9Njj_b7WUorZUM6xV5-HrXQLOSss",
    authDomain: "authentication-f2f1e.firebaseapp.com",
    projectId: "authentication-f2f1e",
    storageBucket: "authentication-f2f1e.appspot.com", //space to store user data
    messagingSenderId: "753556491490",
    appId: "1:753556491490:web:48abcc068306352b5ea2bb",
    measurementId: "G-T6M7QL2629",
  };

firebase.initializeApp(firebaseConfig);
export const auth = firebase.auth(); //method dat allows to handle user authentication in our apps
export const firestore = firebase.firestore(); //DB management
