import {useState} from "react";
import {auth} from "../firebase";
import {useNavigate} from "react-router-dom"; //useHistory

export function LoginForm()
{
    const [email, updateEmailText] = useState("");
    const [password, updatePasswordText] = useState("");
    
    //console.log("email", email, "password", password, "confirm Password", confirmPassword);
    const navigate = useNavigate(); //instance of (useHistory) useNavigate

    async function handleLogin()
    {
            try
            {
                //method to validate user
                const {user} = await auth.signInWithEmailAndPassword(email, password); //auth from firebase.js : import here
                console.log("User Data", user, "User token is", user.refreshToken);
    
                //make an entry to local storage : redirect user to home page
                localStorage.setItem("user Token", user.refreshToken); //store user token : stored in App.js : token remains in local history
    
                //take user to home page
                navigate("/home"); //userToken is taken to home route
           
            }

            catch(e)
            {
                console.log("login error is", e);
                alert(e);
            }
           
    }
    function handleRegistrationRedirect()
    {
        navigate("/register");
    }
    return (
        <div className="w-100">
            <h1>Login</h1>
            <div className="w-50 m-auto form-element-container">
                <div className="form-group">
                    <label for="exampeInputEmail1">Email address</label>
                    <input type="email" className="form-control" id="exampeInputEmail1" 
                    aria-describedby="emailHelp" placeholder="Email"
                    value={email} onChange={(e) => updateEmailText(e.target.value)}/>
                    <small id="emailHelp" className="form-text text-muted">We'll never share your credentials</small>
                </div>
                <div className="form-group mt-3">
                    <label for="exampeInputPassword1">Password</label>
                    <input type="password" className="form-control" id="exampeInputPassword1" placeholder="Password"
                    value={password} onChange={(e) => updatePasswordText(e.target.value)}/>
                </div>
            
                <button type="submit" className="btn btn-primary mt-3" onClick={() => handleLogin()}
                >Submit</button>
                <h3>Not created an account yet?</h3>
                <button className="btn btn-success"
                onClick={() => handleRegistrationRedirect()}>
                    Go to Registration</button>
            </div>

        </div>
    )
}