import {useNavigate} from "react-router-dom";

export function Header()
{
    const navigate = useNavigate();
    function handleLogout()
    {
        localStorage.removeItem("userToken");
        navigate("/login");
    }

    function renderLogoutButton()
    {
        if(localStorage.getItem("userToken"))
        {
            return (
                <button>
                    className={"btn btn-danger mt-4"}
                    onClick={() => handleLogout()}
                </button>
            );
        }
    }
    return (
        <nav className="navbar navbar-light bg-primary">
            <div className="container-fluid">
                <div className="h3 text-center text-light w-75" href="#">
                    Grocery App
                </div>
                <div>
                   {renderLogoutButton()}
                </div>
            </div>
        </nav>
    );
}