import {useState} from "react";
import {auth} from "../firebase";
import {useNavigate} from "react-router-dom"; //

export function RegistrationForm()
{
    const [email, updateEmailText] = useState("");
    const [password, updatePasswordText] = useState("");
    const [confirmPassword, updateConfirmPasswordField] = useState("");
    //console.log("email", email, "password", password, "confirm Password", confirmPassword);
    const navigate = useNavigate(); //instance of (useHistory) useNavigate

    async function handleRegistration()
    {
        if(password === confirmPassword)
        {
            //method to register the user using firebase
            const {user} = await auth.createUserWithEmailAndPassword(email, password); //auth from firebase.js : import here
            console.log("User Data", user, "User token is", user.refreshToken); //refreshToken for authentication purpose otherwise no use of reg/login, /home can be directly accessed
            //token to limit access to /home page

            //make an entry to local storage : redirect user to home page
            localStorage.setItem("user Token", user.refreshToken); //store user token : stored in App.js : token remains in local history : to know the user gets logged in : local Storage Application tab

            //take user to home page after the registration is done
            navigate("/home"); //userToken is taken to home route
        }
        else
        {
            alert("Passswords do not match");
        }
    }
    return (
        <div className="w-100">
            <h1>Registration Form</h1>
            <div className="w-50 m-auto form-element-container">
                <div className="form-group">
                    <label for="exampeInputEmail1">Email address</label>
                    <input type="email" className="form-control" id="exampeInputEmail1" 
                    aria-describedby="emailHelp" placeholder="Email"
                    value={email} onChange={(e) => updateEmailText(e.target.value)}/>
                    <small id="emailHelp" className="form-text text-muted">We'll never share your credentials</small>
                </div>
                <div className="form-group mt-3">
                    <label for="exampeInputPassword1">Password</label>
                    <input type="password" className="form-control" id="exampeInputPassword1" placeholder="Password"
                    value={password} onChange={(e) => updatePasswordText(e.target.value)}/>
                </div>
                <div className="form-group mt-3">
                    <label for="exampeInputPassword1">Confirm Password</label>
                    <input type="password" className="form-control" id="exampeInputPassword1" placeholder="Confirm Password"
                    value={confirmPassword} onChange={(e) => updateConfirmPasswordField(e.target.value)}/>
                </div>
                <button type="submit" className="btn btn-primary mt-3" onClick={() => handleRegistration()}
                >Submit</button>
            </div>

        </div>
    )
}