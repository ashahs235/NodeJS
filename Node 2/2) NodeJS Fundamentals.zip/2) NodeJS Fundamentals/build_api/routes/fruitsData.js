const fs = require("fs"); //built in nodejs module - readFile 

/**
 * Function to read a file from local project directory
 * & send it back to client side
 * @param {*} pathString 
 * @param {*} res 
 */

function fruitsDataRoute(pathString, res)
{
    fs.readFile(pathString, function(err, data){
        console.log("Err", err,  "data is", data); //raw data : buffer data
        console.log(JSON.parse(data)); //proper JSON format : JSON.parse is used to convert any kind of data into JSON obj
        
        //converting buffer data to JSON object
        const dataFromFile = JSON.parse(data);
        console.log(dataFromFile.results);
        //send data back to client end
        res.setHeader("Content-Type", "application/json");
        res.write(JSON.stringify(dataFromFile)); //converts JSON obj to string
        res.end();
    });
}

module.exports.fruitsDataRoute = fruitsDataRoute;