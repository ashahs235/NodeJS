import './App.css';
import {useEffect, useState} from "react"; //useEffect to use axios only once
import axios from "axios";
function App()
 {
   const [studentData, updateStudentDetails] = useState([]);
   async function fetchStudentDetails()
   {
     const studentDetails = await axios.get("https://peaceful-temple-23480.herokuapp.com/students/getDetails");
     //To display on browser
     const studentsArray = studentDetails.data.results;
     const studentsUIObject = studentsArray.map((item)=>{
      //return <div>{item}</div>; //error
      //return <div>{item.name}</div>; //only individual values can be displayed
      return (<div>
          <div>{item.name}</div>
          <div>{item.rollNo}</div>
          <div>{item.branch}</div>
       </div>);
   });
     
     console.log("All details", studentDetails);
     console.log("Only data", studentDetails.data.results);
     updateStudentDetails(studentsUIObject);
   }
    useEffect(()=>{
      fetchStudentDetails()
    }, [])
    return (
      <div className="App">
        <header className="App-header">
          {studentData}
        </header>
      </div>
    );
 }

export default App;
